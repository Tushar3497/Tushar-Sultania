# Library-Management-System-using-C
It is a console based library management system application that can be used to manage a library digitally. 
It is programmed using C language.
It has all basic functions such as to add book and reader, search book and reader, issuing and submitting a book, delete book and reader, and print list of all books in library. While issuing a book the reader will be checked if they have a book pending to submit. Also, the availability of a book is mentioned in book details.
Main advantage of this project is that it makes it way easy to manage a library. Keeping track of the data is easy this way.
It significantly helps in reducing the use of paper in library management.
